[![Arduino CLI build](https://github.com/nRF24/RF24/workflows/Arduino%20CLI%20build/badge.svg)](https://github.com/nRF24/RF24/actions?query=workflow%3A%22Arduino+CLI+build%22)
[![Linux build](https://github.com/nRF24/RF24/workflows/Linux%20build/badge.svg)](https://github.com/nRF24/RF24/actions?query=workflow%3A%22Linux+build%22)

# See http://nRF24.github.io/RF24 for all documentation

### Check our [contributing guidelines](CONTRIBUTING.md) before opening a pull request
